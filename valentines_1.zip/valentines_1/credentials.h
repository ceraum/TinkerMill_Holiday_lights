
#pragma once
const char* mySSID = "ELFNET";
const char* myPASSWORD = "N4augty||Nic3";