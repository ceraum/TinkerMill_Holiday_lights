// variables.h
#ifndef VARIABLES_H
#define VARIABLES_H

const int panels[][2] = {
  {51, 5}, // First panel configuration: 51 LEDs, 5 segments
  {122, 15},
  {130, 15},
  {78, 15},
  {78, 15},
  {83, 15},
  {82, 9},
  {82, 9},
  {82, 9},
  // Add more configurations as needed
};

#endif // VARIABLES_H

// Window perimeters, for all but windows one and two are total
const int perimeters [][4] = {
  {117,	50,	100},
  {520, 102,	265, 363},
  {517, 104,	259, 360},
  {265,	70,	199},
  {269,	70,	200},
  {280,	70,	214},
  {230, 70, 160},
  {230, 71, 160},
  {250, 70, 175}
};

// Use the fuseID to return the correct window name
int windowNum (uint64_t var) {

  int thisNum;

  switch (var) {
  case 264390250713352:
    //thisName = "win0";
    thisNum = 0;
    break;
  case 202580436832520:
    //thisName = "win1";
    thisNum = 1;
    break;
  case 158785661948168:
    //thisName = "win2";
    thisNum = 2;
    break;
  case 278167046181128:
    //thisName = "win3";
    thisNum = 3;
    break;
  case 255446076935576:
    //thisName = "win4";
    thisNum = 4;
    break;
  case 198418596745480:
    //thisName = "win5";
    thisNum = 5;
    break;
  case 198512032212808:
    //thisName = "win6";
    thisNum = 6;
    break;
  case 158342005248264:
    //thisName = "win7";
    thisNum = 7;
    break;
  case 242038301380872:
    //thisName = "win8";
    thisNum = 8;
    break;
  
  default:
    thisNum = 99;
    break;
  }

  return thisNum;
}